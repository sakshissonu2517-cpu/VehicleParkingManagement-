VEHICLE PARKING MANAGEMENT SYSTEM
Java OOP Practical Mini Project

Student Name : SAKSHI S
SRN          : R24SA034
Program      : B.Sc. BSTCs
Semester     : V

==================================================
1. PROJECT DESCRIPTION
==================================================

The Vehicle Parking Management System is a Java-based
console application developed using Object-Oriented
Programming concepts.

The system allows the user to:
- Add cars and bikes.
- Assign vehicles to parking slots.
- Display parked vehicles.
- Search for a vehicle.
- Calculate parking fees.
- Display parking rules.
- Display the total number of parked vehicles.
- Exit the system.

==================================================
2. TECHNOLOGIES USED
==================================================

Programming Language : Java
JDK Version          : JDK 27
IDE                  : Visual Studio Code
Input                : Scanner
Application Type     : Console-based Java Application

==================================================
3. PROJECT STRUCTURE
==================================================

VehicleParkingManagement
|
|-- README.txt
|
|-- src
    |
    |-- main
    |   |-- Main.java
    |
    |-- model
    |   |-- Vehicle.java
    |   |-- Car.java
    |   |-- Bike.java
    |   |-- ParkingSlot.java
    |   |-- ParkingFee.java
    |   |-- VehicleType.java
    |
    |-- service
        |-- ParkingService.java


==================================================
4. MAPPING OF JAVA OOP REQUIREMENTS
==================================================

1. Classes and Encapsulation
   File: Vehicle.java, Car.java, Bike.java,
         ParkingSlot.java, ParkingService.java
   Private fields are accessed using getters and setters.

2. Data Types, final and Variable Scope
   Files: Car.java, Bike.java, ParkingService.java
   int, double, boolean and String data types are used.
   final constants are used for fixed values.

3. Operators and Operator Precedence
   File: Car.java
   Expression:
   hours * RATE_PER_HOUR + baseFee
   Multiplication is performed before addition.

4. Type Conversion and Casting
   File: Main.java
   Explicit casting is used:
   Car selectedCar = (Car) feeVehicle;

5. Enum
   File: VehicleType.java
   Values used:
   CAR, BIKE, SUV

6. Conditional Statements, Switch, Loops, Break,
   Continue and Return
   File: Main.java
   if-else, switch, while loop, break and continue
   are used.
   Return statements are used in service methods.

7. Array/List of Objects
   File: ParkingService.java
   ArrayList<Vehicle> is used to store vehicle objects.

8. Scanner and Formatted Output
   File: Main.java
   Scanner is used for user input.
   printf() is used for formatted output.

9. Constructor Overloading
   Files: Vehicle.java, Car.java, Bike.java,
          ParkingSlot.java
   Default and parameterized constructors are provided.

10. Method Overloading
    File: ParkingService.java
    addVehicle(Vehicle vehicle)
    addVehicle(Vehicle vehicle, ParkingSlot slot)

11. Static Fields and Methods
    File: ParkingService.java
    Static field:
    totalVehicles

    Static method:
    getTotalVehicles()

12. this Reference
    File: Vehicle.java
    this.vehicleNumber and this.ownerName are used.

13. String Methods
    File: Main.java
    trim(), toUpperCase() and equalsIgnoreCase()
    are used.

14. Base Class and Two Subclasses
    Base class:
    Vehicle

    Subclasses:
    Car
    Bike

15. super Keyword
    Files: Car.java and Bike.java
    super() and super(...) are used to call the
    parent class constructor.

16. Method Overriding and Dynamic Binding
    Files: Car.java, Bike.java and Vehicle.java
    calculateFee() and toString() are overridden.
    Vehicle references can refer to Car and Bike objects.

17. Abstract Class and Abstract Method
    File: Vehicle.java
    Vehicle is an abstract class.
    calculateFee(int hours) is declared as an
    abstract method and implemented by Car and Bike.

18. Interface and Interface Reference
    File: ParkingFee.java
    ParkingFee is an interface.

    File: ParkingService.java
    A ParkingFee interface reference is used to
    calculate the parking fee.

19. toString() and equals()
    File: Vehicle.java
    toString() and equals() methods are overridden.

20. Final Method
    File: ParkingService.java
    displayParkingRules() is declared final because
    the parking rules should not be overridden.

21. Custom Packages and Imports
    Custom packages:
    model
    service

    The Main class imports classes from these packages.


==================================================
5. SAMPLE CONSOLE OUTPUT
==================================================

================================
   VEHICLE PARKING MANAGEMENT
================================
1. Add Car
2. Add Bike
3. Show Vehicles
4. Search Vehicle
5. Calculate Parking Fee
6. Show Parking Rules
7. Show Total Vehicles
8. Exit
Enter your choice: 1

Enter car number: KA01AB1234
Enter owner name: Sakshi
Enter number of doors: 4
Vehicle added to slot 1


Enter your choice: 2

Enter bike number: KA02XY5678
Enter owner name: Rahul
Does the bike have gears? (yes/no): yes
Vehicle added to slot 2


Enter your choice: 3

--- Parked Vehicles ---
Vehicle Number: KA01AB1234, Owner Name: Sakshi,
Number of Doors: 4

Vehicle Number: KA02XY5678, Owner Name: Rahul,
Has Gear: true


Enter your choice: 5

Enter vehicle number: KA01AB1234
Enter parking hours: 3
Vehicle: KA01AB1234 | Hours: 3 | Parking Fee: 170.00
This is a car with 4 doors.


Enter your choice: 7
Total vehicles parked: 2


Enter your choice: 6

--- Parking Rules ---
1. Maximum vehicles allowed: 10
2. Vehicles must be parked in assigned slots.
3. Parking fees depend on vehicle type.


Enter your choice: 8
Exiting the system...
Thank you for using Vehicle Parking Management System.


==================================================
6. CONCLUSION
==================================================

The Vehicle Parking Management System demonstrates
important Java Object-Oriented Programming concepts
including encapsulation, inheritance, abstraction,
polymorphism, interfaces, constructors, method
overloading, method overriding, packages, enums,
static members and exception-safe input handling.

The project provides a simple console-based solution
for managing vehicles and parking information.