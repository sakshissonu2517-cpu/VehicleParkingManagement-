package model;

public interface ParkingFee {

    double calculateFee(int hours);
}