package model;

public class ParkingSlot {

    private int slotNumber;
    private VehicleType vehicleType;
    private Vehicle vehicle;
    private boolean occupied;

    public ParkingSlot() {
        this.occupied = false;
    }

    public ParkingSlot(int slotNumber, VehicleType vehicleType) {
        this.slotNumber = slotNumber;
        this.vehicleType = vehicleType;
        this.occupied = false;
    }

    public int getSlotNumber() {
        return slotNumber;
    }

    public void setSlotNumber(int slotNumber) {
        this.slotNumber = slotNumber;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(VehicleType vehicleType) {
        this.vehicleType = vehicleType;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public void parkVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
        this.occupied = true;
    }

    public void removeVehicle() {
        this.vehicle = null;
        this.occupied = false;
    }

    @Override
    public String toString() {
        return "Slot Number: " + slotNumber
                + ", Vehicle Type: " + vehicleType
                + ", Occupied: " + occupied
                + ", Vehicle: " + vehicle;
    }
}
