package model;

public class Bike extends Vehicle {

    private boolean hasGear;

    public Bike() {
        super();
    }

    public Bike(String vehicleNumber, String ownerName, boolean hasGear) {
        super(vehicleNumber, ownerName);
        this.hasGear = hasGear;
    }

    public boolean isHasGear() {
        return hasGear;
    }

    public void setHasGear(boolean hasGear) {
        this.hasGear = hasGear;
    }

    @Override
    public double calculateFee(int hours) {

        final double RATE_PER_HOUR = 20.0;

        return hours * RATE_PER_HOUR;
    }

    @Override
    public String toString() {
        return super.toString()
                + ", Has Gear: " + hasGear;
    }
}
