package model;

public class Car extends Vehicle {

    private int numberOfDoors;

    public Car() {
        super();
    }

    public Car(String vehicleNumber, String ownerName, int numberOfDoors) {
        super(vehicleNumber, ownerName);
        this.numberOfDoors = numberOfDoors;
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public void setNumberOfDoors(int numberOfDoors) {
        this.numberOfDoors = numberOfDoors;
    }

    @Override
    public double calculateFee(int hours) {

        final double RATE_PER_HOUR = 50.0;
        double baseFee = 20.2;

        return hours * RATE_PER_HOUR + baseFee;
    }

    @Override
    public String toString() {
        return super.toString()
                + ", Number of Doors: " + numberOfDoors;
    }
}
    

