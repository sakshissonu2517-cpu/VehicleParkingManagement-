package service;

import model.ParkingSlot;
import model.Vehicle;
import model.ParkingFee;
import java.util.ArrayList;
import java.util.List;

public class ParkingService {

    private List<Vehicle> vehicles = new ArrayList<>();

    // Static field
    private static int totalVehicles = 0;

    // Final constant
    private static final int MAX_VEHICLES = 10;

    // Add vehicle - method overloading
    public void addVehicle(Vehicle vehicle) {

        if (totalVehicles >= MAX_VEHICLES) {
            System.out.println("Parking limit reached.");
            return;
        }

        vehicles.add(vehicle);
        totalVehicles++;

        System.out.println("Vehicle added successfully.");
    }

    // Overloaded method
    public void addVehicle(Vehicle vehicle, ParkingSlot slot) {

        if (slot.isOccupied()) {
            System.out.println("Parking slot is already occupied.");
            return;
        }

        if (totalVehicles >= MAX_VEHICLES) {
            System.out.println("Parking limit reached.");
            return;
        }

        vehicles.add(vehicle);
        slot.parkVehicle(vehicle);
        totalVehicles++;

        System.out.println("Vehicle added to slot " + slot.getSlotNumber());
    }

    public void showVehicles() {

        if (vehicles.isEmpty()) {
            System.out.println("No vehicles parked.");
            return;
        }

        System.out.println("\n--- Parked Vehicles ---");

        for (Vehicle vehicle : vehicles) {
            System.out.println(vehicle);
        }
    }

    // Search vehicle
    public Vehicle searchVehicle(String vehicleNumber) {

        for (Vehicle vehicle : vehicles) {

            if (vehicle.getVehicleNumber().equalsIgnoreCase(vehicleNumber)) {
                return vehicle;
            }
        }

        return null;
    }

    // Static method
    public static int getTotalVehicles() {
        return totalVehicles;
    }

    // Final method
    public final void displayParkingRules() {

        System.out.println("\n--- Parking Rules ---");
        System.out.println("1. Maximum vehicles allowed: " + MAX_VEHICLES);
        System.out.println("2. Vehicles must be parked in assigned slots.");
        System.out.println("3. Parking fees depend on vehicle type.");
    }

    // Calculate fee using interface reference
    public void displayFee(Vehicle vehicle, int hours) {
        ParkingFee feeCalculator = vehicle;
        double fee = feeCalculator.calculateFee(hours);

        System.out.printf(
                "Vehicle: %s | Hours: %d | Parking Fee: %.2f%n",
                vehicle.getVehicleNumber(),
                hours,
                fee
        );
    }
}